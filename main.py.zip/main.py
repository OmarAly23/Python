# Homework#1 python 
Artist = "Abel Tesfaye" # title of the artist
StageName = "The Weeknd" # the stage name of the artist
Genre = "R&B" # title of the genre
Album = "After Hours" # title of the album
song = "Blinding Lights" # title of the song
yearReleased = 2019 # year the song was released
DurationInMin = 4 # The duration of the song in minutes
DurationInSEC = 22 # The duration of the song in seconds
Nominations = "Song of the year"



# Printing each variable in a separate line 
print("The artist : " , Artist)
print("Known as : ", StageName)
print("The genre : ", Genre)
print("The album : ", Album)
print("The song : ", song)
print("The year it was released : ", yearReleased)
print("The duration of the song : ", DurationInMin, "mins", DurationInSEC, "secs")
print("Nominations : ", Nominations)

